# AplicacionMuseo
Aplicacion para  tener informacion sobre un museo para la asignatura de Nuevos Paradigmas de Interacion

La aplicacion esta pensada para Android 7.0

Para poder compilar la aplicacion hace falta el archivo google-services.json. Este archivo forma parte del proyecto 
de Firebase y se descarga desde la consola de desarrollador. El archivo tiene que encontrarse en la carpeta:
/mobile/google-services.json
